import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Cars extends PApplet {

Car[] cars = new Car[100];

public void setup() {
  
  for(int i=0; i<cars.length; i++) {
    cars[i] = new Car(color(random(255),random(255),random(255)));
  }
}

public void draw() {
  background(255);
  for(int i=0; i<cars.length; i++) {
    cars[i].display();
    cars[i].drive();
  }
}
class Car {
  // member variables
  int c;
  float xpos, ypos, xspeed;
  boolean right;

  //Constructor
  Car(int c) {
    this.c = c;
    xpos = random(width);
    ypos = random(height);
    xspeed = random(1, 5);
    if (random(10)>5) {
      right = true;
    } else {
      right = false;
    }
  }

  public void display() {
    rectMode(CENTER);
    fill(c);
    rect(xpos, ypos, 20, 10, 4);
    fill(0);
    rect(xpos-7, ypos-4, 5, 3);
    rect(xpos-7, ypos+4, 5, 3);
    rect(xpos+7, ypos-4, 5, 3);
    rect(xpos+7, ypos+4, 5, 3);
  }

  public void drive() {
    if (right) {
      xpos += xspeed;
      if (xpos > width) {
        xpos = 0;
      } else {
        xpos -= xspeed;
        if (xpos < 0) {
          xpos = width;
        }
      }
    }
  }
}
  public void settings() {  size(500, 500); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Cars" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
